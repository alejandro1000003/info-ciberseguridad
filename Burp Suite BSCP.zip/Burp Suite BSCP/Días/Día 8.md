---
tags:
  - api_path
---
Hoy he acabado el lab que me dejé el otro día por hacer, cosa de buscar dónde estaba la api, que métodos tenía y jugar con las variables del json (en este caso cambiar el descuento al 100%).
![[Pasted image 20240515195332.png]]


