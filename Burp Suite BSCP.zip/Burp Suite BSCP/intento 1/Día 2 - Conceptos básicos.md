1/ Portswinger
---
- Concepto nuevo ***security by obscurity***
- Lab: Unprotected admin functionality with unpredictable URL (**completado**)
	El link estaba en el código fuente de la misma página, este es un caso dónde no se puede usar ffuf porque la url es impredecible

2/ TryHackMe
---
Teoría básica de web
![[Pasted image 20240423220148.png]]

**Resumen de conceptos básicos**
El DNS actúa como el GPS de Internet. Cuando quieres acceder a una página web, le preguntas al DNS y te indica la dirección IP correspondiente. Es básicamente la agenda telefónica de la web, facilitándote encontrar sitios sin tener que memorizar direcciones IP.

Por otro lado, el HTTP es el protocolo que utilizan las páginas web y los navegadores para comunicarse entre sí. Este protocolo permite solicitar y mostrar el contenido de una página web de manera clara y ordenada, haciendo que la navegación sea más fluida y fácil de entender.