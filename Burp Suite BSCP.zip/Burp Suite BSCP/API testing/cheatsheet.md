### Reconocimiento
- ffuf de api endpoints
- burp crawler -> You can also gather a lot of information by browsing applications that use the API
- Also look out for JavaScript files (JS Link Finder, extensión de burpsuite)
- Usa burp repeater y intruder
- Probar diferentes métodos HTTP