---
tags:
  - api_path
---
g**Conceptos nuevo**
>  **El símbolo #** en una URL indica un fragmento o ancla, que el navegador usa para identificar y desplazarse a una sección específica de una página web. No se envía al servidor.
>
> **Un query string** es una cadena de texto en una URL que contiene parámetros clave-valor utilizados para pasar información a un servidor web. **La contaminación de parámetros puede ocurrir en una query string** 
> 
> **La contaminación de parámetros** ocurre cuando múltiples valores para el mismo parámetro en el query string causan comportamientos inesperados o vulnerabilidades de seguridad.
>
> **Los parámetros del lado del servidor** son valores procesados por el servidor que controlan su comportamiento

## Lab: Exploiting server-side parameter pollution in a query string

Este laboratorio la verdad es que en comparación con los anteriores era complicado, he tenido que buscar la respuesta a medias.

Gracias a este laboratorio he descubierto que el historial de peticiones del proxy es muy útil porque si te limitas a interceptar manualmente peticiones http, lo más probable es que te estés saltando una petición complicada de interceptar, mientras que si vas navegando con el proxy en escucha, el historial http recoge todo sin que tengas que revisar petición por petición.

![[Pasted image 20240525180109.png]]

Después de navegar un rato por la web interceptando peticiones, nos encontramos con dos páginas que parecen interesantes.

![[Pasted image 20240525180220.png]]

La primera te permite visualizar parte de el correo electrónico de una cuenta en particular

