---
tags:
  - cheatsheet
  - sqli
---

## Links a los cheatsheet online
https://portswigger.net/web-security/sql-injection/cheat-sheet
https://github.com/payloadbox/sql-injection-payload-list/blob/master/README.md