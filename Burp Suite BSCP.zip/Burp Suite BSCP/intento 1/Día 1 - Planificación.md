### Rutas de aprendizaje hacking web
- **Portswigger** ([https://portswigger.net/web-security/learning-paths](https://portswigger.net/web-security/learning-paths))
- https://tryhackme.com/r/hacktivities

Hoy he creado una cuenta en portswigger y he empezado la ruta de aprendizaje "Server-side vulnerabilities"

1/ Portswinger
---
## Práctica 1
[[File inclusion]] (apuntes)
**Completado lab 1 (básico)**
El laboratorio consistía en usar la url de la imagen donde carga la imagen directamente accediendo al disco duro generando una vulnerabilidad. Si modificas la **url** puedes acceder a archivos del servidor.

![[Pasted image 20240422203444.png]]

## Práctica 2
[[Acces control]] (apuntes)
Lab completad (Unprotected admin functionality)

Consistía en encontrar /administrator-panel y este no tenía ningún tipo de protección *(se puede hacer con ffuf por ejemplo)*

![[Pasted image 20240422205621.png]]